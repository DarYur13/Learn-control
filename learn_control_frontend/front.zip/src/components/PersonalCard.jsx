import React, { useState } from "react";
import { Container, Paper, Typography, TextField, Box, Divider, IconButton } from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import SaveIcon from "@mui/icons-material/Save";

export default function PersonalCard({ employee, onSaveDate }) {
  const [editingTraining, setEditingTraining] = useState(null);
  const [date, setDate] = useState(null);

  const handleEditClick = (training) => {
    if (editingTraining?.id === training.id) {
      setEditingTraining(null);
      setDate(null);
    } else {
      setEditingTraining(training);
      setDate(training.passDate || "");
    }
  };

  const handleSaveDate = () => {
    if (editingTraining && date) {
      onSaveDate(employee.id, editingTraining.id, date);
      setEditingTraining(null);
      setDate(null);
    }
  };

  return (
    <Container maxWidth="md" sx={{ mt: 4 }}>
      <Paper elevation={3} sx={{ p: 4, borderRadius: 3 }}>
        {/* Заголовок */}
        <Typography variant="h5" fontWeight="bold" align="center" gutterBottom>
          Личная карта сотрудника
        </Typography>
        <Divider sx={{ mb: 3 }} />

        {/* Основные данные */}
        <Box sx={{ display: "flex", flexDirection: "column", gap: 1 }}>
          <Typography variant="h6">{employee.fullname}</Typography>
          <Typography variant="body1">📅 Дата рождения: {employee.birthdate}</Typography>
          <Typography variant="body1">📄 СНИЛС: {employee.snils}</Typography>
          <Typography variant="body1">🏢 Отдел: {employee.department}</Typography>
          <Typography variant="body1">💼 Должность: {employee.position}</Typography>
          <Typography variant="body1">📆 Дата приёма: {employee.employmentDate}</Typography>
        </Box>

        <Divider sx={{ my: 3 }} />

        {/* Блок обучений */}
        <Typography variant="h6" fontWeight="bold" gutterBottom>
          Обучения:
        </Typography>

        {employee.trainings.length === 0 ? (
          <Typography color="textSecondary">Нет пройденных обучений</Typography>
        ) : (
          employee.trainings.map((training) => (
            <Box
              key={training.id}
              sx={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                p: 2,
                borderRadius: 2,
                backgroundColor: "#f9f9f9",
                mb: 1,
              }}
            >
              <Box>
                <Typography variant="body1" fontWeight="bold">
                  {training.name}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Перепрохождение: {training.rePassDate || "-"}
                </Typography>
              </Box>

              <Box sx={{ display: "flex", alignItems: "center", gap: 1 }}>
                {editingTraining?.id === training.id ? (
                  <TextField
                    type="date"
                    size="small"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                  />
                ) : (
                  <Typography sx={{ minWidth: 100, textAlign: "right" }}>
                    {training.passDate || "Не пройдено"}
                  </Typography>
                )}

                <IconButton
                  color={editingTraining?.id === training.id ? "success" : "primary"}
                  onClick={() =>
                    editingTraining?.id === training.id ? handleSaveDate() : handleEditClick(training)
                  }
                >
                  {editingTraining?.id === training.id ? <SaveIcon /> : <EditIcon />}
                </IconButton>
              </Box>
            </Box>
          ))
        )}
      </Paper>
    </Container>
  );
}
